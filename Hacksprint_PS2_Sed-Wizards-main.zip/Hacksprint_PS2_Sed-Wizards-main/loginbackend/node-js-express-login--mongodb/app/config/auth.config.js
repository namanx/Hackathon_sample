module.exports = {
    secret: "vijay-secret-key"
  };