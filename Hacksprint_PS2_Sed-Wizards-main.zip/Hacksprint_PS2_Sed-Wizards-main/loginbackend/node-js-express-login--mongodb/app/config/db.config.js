module.exports = {
    HOST: "localhost",
    PORT: 27017,
    DB: "bezkoder_db"
  };
  
  